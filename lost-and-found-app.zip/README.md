# Lost & Found App

A simple Streamlit app to report lost items, claim found items, and browse recent items.

## Features
- User login / sign up
- Report lost items
- Claim found items
- Search recent items
- Persistent navigation via sidebar

## Deployment
Deploy directly on Streamlit Community Cloud by connecting your GitHub repo.
